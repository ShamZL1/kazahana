package com.example.kazahana

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
