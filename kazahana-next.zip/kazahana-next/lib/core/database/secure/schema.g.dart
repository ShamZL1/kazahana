// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'schema.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

SecureSchema _$SecureSchemaFromJson(Map<String, dynamic> json) => SecureSchema(
      anilistToken: SecureSchema._anilistTokenFromJson(json['anilistToken']),
    );

Map<String, dynamic> _$SecureSchemaToJson(SecureSchema instance) =>
    <String, dynamic>{
      'anilistToken': SecureSchema._anilistTokenToJson(instance.anilistToken),
    };
