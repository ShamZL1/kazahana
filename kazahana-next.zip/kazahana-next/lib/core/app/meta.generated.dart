part of 'meta.dart';

abstract class _GeneratedAppMeta {
  static const String version = '3.0.0';
  static const int builtAtMs = 1659024927924;
}
