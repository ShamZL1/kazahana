export 'anilist.dart';
