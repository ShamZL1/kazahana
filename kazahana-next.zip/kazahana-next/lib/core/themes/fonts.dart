abstract class Fonts {
  static const String inter = 'Inter';
  static const String greatVibes = 'GreatVibes';
}
