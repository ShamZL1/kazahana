abstract class AnilistCredentials {
  static const String clientId = '6444';
}
