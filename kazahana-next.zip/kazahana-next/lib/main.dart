import 'package:flutter/material.dart';
import 'package:kazahana/ui/exports.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const BaseApp());
}
