import 'package:kazahana/core/exports.dart';

final GlobalKey<NavigatorState> gNavigatorKey = GlobalKey<NavigatorState>();
